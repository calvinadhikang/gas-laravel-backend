<?php

namespace App\Http\Controllers;

use App\Models\Vendor;
use Illuminate\Http\Request;

class VendorController extends Controller
{
    public function getAll() {
        $vendors = Vendor::all();

        return response()->json([
            'message' => 'Success',
            'data' => $vendors
        ], 200);
    }

    public function getDetail($id) {
        $vendor = Vendor::find($id);

        return response()->json([
            'message' => 'Success',
            'data' => $vendor
        ], 200);
    }

    public function create(Request $request) {
        $vendor = Vendor::create($request->all());

        return response()->json([
            'message' => 'Success',
            'data' => $vendor
        ], 201);
    }

    public function update(Request $request, $id) {
        $vendor = Vendor::find($id);
        $vendor->update($request->all());

        return response()->json([
            'message' => 'Success',
            'data' => $vendor
        ], 201);
    }
}
